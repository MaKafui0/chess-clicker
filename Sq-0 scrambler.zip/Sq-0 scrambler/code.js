var no1 = randomNumber (-1,2) * 3;
var no2 = randomNumber (-1,2) * 3;
var no3 = randomNumber (-1,2) * 3;
var no4 = randomNumber (-1,2) * 3;
var no5 = randomNumber (-1,2) * 3;
var no6 = randomNumber (-1,2) * 3;
var no7 = randomNumber (-1,2) * 3;
var no8 = randomNumber (-1,2) * 3;
var no9 = randomNumber (-1,2) * 3;
var no10 = randomNumber (-1,2) * 3;
var no11 = randomNumber (-1,2) * 3;
var no12 = randomNumber (-1,2) * 3;
var no13 = randomNumber (-1,2) * 3;
var no14 = randomNumber (-1,2) * 3;
var sq0l = 0;
onEvent ("buttonreset", "click", function() {
no1 = randomNumber (-1,2) * 3;
no2 = randomNumber (-1,2) * 3;
no3 = randomNumber (-1,2) * 3;
no4 = randomNumber (-1,2) * 3;
no5 = randomNumber (-1,2) * 3;
no6 = randomNumber (-1,2) * 3;
no7 = randomNumber (-1,2) * 3;
no8 = randomNumber (-1,2) * 3;
no9 = randomNumber (-1,2) * 3;
no10 = randomNumber (-1,2) * 3;
no11 = randomNumber (-1,2) * 3;
no12 = randomNumber (-1,2) * 3;
no13 = randomNumber (-1,2) * 3;
no14 = randomNumber (-1,2) * 3;
//ones
if (no1==0) {
  if (no2==0) {
    setText("labelscram", "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
    sq0l = sq0l + 1;
  }
}
if (no1!=0) {
  if(no2!=0){
    sq0l = sq0l = 0;
  }
}
if (no3==0) {
  if (no4==0) {
    sq0l = sq0l + 1;
    setText("labelscram", "/" + no1 + "," + no2 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
  }}
if (no3!=0) {
  if(no4!=0){
    sq0l = sq0l = 0;
  }
}
  if (no5==0) {
    if (no6==0) {
      sq0l = sq0l + 1;
      setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
  }}
if (no5!=0) {
  if(no6!=0){
    sq0l = sq0l = 0;
  }
}
  if (no7==0) {
    if (no8==0) {
      sq0l = sq0l + 1;
      setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
  }}
  if (no7!=0) {
  if(no8!=0){
    sq0l = sq0l = 0;
  }
}
  if (no9==0) {
    if (no10==0) {
      sq0l = sq0l + 1;
      setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
  }}
  if (no9!=0) {
  if(no10!=0){
    sq0l = sq0l = 0;
  }
}
  if (no11==0) {
    if (no12==0) {
      sq0l = sq0l + 1;
      setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no13 + "," + no14 + "/");
  }}
  if (no11!=0) {
  if(no12!=0){
    sq0l = sq0l = 0;
  }
}
  if (no13==0) {
    if (no14==0) {
      sq0l = sq0l + 1;
      setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/");
  }}
  if (no13!=0) {
  if(no14!=0){
    sq0l = sq0l = 0;
  }
}
//twos
if (no1==0) {
  if (no2==0) {
    if (no3==0) {
      if (no4==0) {
        setText("labelscram", ("/" + no5) + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}
  }
}
if (no1==0) {
  if (no2==0) {
    if (no5==0) {
      if (no6==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}
  }
}
if (no3==0) {
  if (no4==0) {
    if (no5==0) {
      if (no6==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no1==0) {
  if (no2==0) {
    if (no7==0) {
      if (no8==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no3==0) {
  if (no4==0) {
    if (no7==0) {
      if (no8==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no5 + "," + no6 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no5==0) {
  if (no6==0) {
    if (no7==0) {
      if (no8==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no1==0) {
  if (no2==0) {
    if (no9==0) {
      if (no10==0) {
        setText("labelscram", ("/" + no3) + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no11  + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no3==0) {
  if (no4==0) {
    if (no9==0) {
      if (no10==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no11  + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no5==0) {
  if (no6==0) {
    if (no9==0) {
      if (no10==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no11  + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no7==0) {
  if (no8==0) {
    if (no9==0) {
      if (no10==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no11  + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no1==0) {
  if (no2==0) {
    if (no11==0) {
      if (no12==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no3==0) {
  if (no4==0) {
    if (no11==0) {
      if (no12==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no5==0) {
  if (no6==0) {
    if (no11==0) {
      if (no12==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no7==0) {
  if (no8==0) {
    if (no11==0) {
      if (no12==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no9  + "," + no10 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no9==0) {
  if (no10==0) {
    if (no11==0) {
      if (no12==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7  + "," + no8 + "/" + no13 + "," + no14 + "/");
      }}}}
if (no1==0) {
  if (no2==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no3) + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no11 + "," + no12 + "/");
      }}}}
if (no3==0) {
  if (no4==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no11 + "," + no12 + "/");
      }}}}
if (no5==0) {
  if (no6==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no9  + "," + no10 + "/" + no11 + "," + no12 + "/");
      }}}}
if (no7==0) {
  if (no8==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no9  + "," + no10 + "/" + no11 + "," + no12 + "/");
      }}}}
if (no9==0) {
  if (no10==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7  + "," + no8 + "/" + no11 + "," + no12 + "/");
      }}}}
if (no11==0) {
  if (no12==0) {
    if (no13==0) {
      if (no14==0) {
        setText("labelscram", ("/" + no1) + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7  + "," + no8 + "/" + no9 + "," + no10 + "/");
      }}}}
//threes (this is pain)
if (no1==0) {
  if (no2==0) {
    if (no3==0) {
      if (no4==0) {
        if (no5==0) {
          if (no6==0) {
        setText("labelscram", "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no3==0) {
      if (no4==0) {
        if (no7==0) {
          if (no8==0) {
        setText("labelscram", "/" + no5 + "," + no6 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no5==0) {
      if (no6==0) {
        if (no7==0) {
          if (no8==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no3==0) {
  if (no4==0) {
    if (no5==0) {
      if (no6==0) {
        if (no7==0) {
          if (no8==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no3==0) {
      if (no4==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no3==0) {
      if (no4==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no5==0) {
      if (no6==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no7 + "," + no8 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no3==0) {
  if (no4==0) {
    if (no5==0) {
      if (no6==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no7 + "," + no8 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1==0) {
  if (no2==0) {
    if (no7==0) {
      if (no8==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no3==0) {
  if (no4==0) {
    if (no7==0) {
      if (no8==0) {
        if (no9==0) {
          if (no10==0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no5 + "," + no6 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }}}}}}
if (no1!=0) {
  if (no2!=0) {
    if (no3 != 0) {
      if (no4 != 0) {
        setText("labelscram", "/" + no1 + "," + no2 + "/" + no3 + "," + no4 + "/" + no5 + "," + no6 + "/" + no7 + "," + no8 + "/" + no9 + "," + no10 + "/" + no11 + "," + no12 + "/" + no13 + "," + no14 + "/");
      }
    }
  }}
});
